
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class Payment {

    String expireDate;

    Scanner sc = new Scanner(System.in);

    public void processPayment(int user_ID, int flight_ID) {
        JTextField cardField = new JTextField(24);
        JTextField expireDateField = new JTextField(15);
        JTextField cvvField = new JTextField(5);

        JPanel myPanel = new JPanel();
        myPanel.setLayout(new BoxLayout(myPanel, BoxLayout.Y_AXIS));
        myPanel.add(new JLabel("Card Number:"));
        myPanel.add(cardField);
        myPanel.add(Box.createVerticalStrut(15));
        myPanel.add(new JLabel("Enter expiry date (dd/mm/yyyy):"));
        myPanel.add(expireDateField);
        myPanel.add(Box.createVerticalStrut(15));
        myPanel.add(new JLabel("Enter CVV number:"));
        myPanel.add(cvvField);

        int result = JOptionPane.showConfirmDialog(null, myPanel, "Please enter values", JOptionPane.OK_CANCEL_OPTION);
        if (result == JOptionPane.OK_OPTION) {

            String CardNo = cardField.getText();
            expireDate = expireDateField.getText();
            int cvvNo = Integer.parseInt(cvvField.getText());
            boolean verify = verifyPayment(expireDate);
            if (verify) {
                Booking booking = new Booking();
                booking.createBooking(user_ID, flight_ID, "Confirmed");
            } else {
                JOptionPane.showMessageDialog(null, "Payment dicline ");
            }
        }
    }

    public boolean verifyPayment(String expire_date) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        sdf.setLenient(false);
        try {
            Date expirDate = sdf.parse(expire_date);
            Date date = new Date();
            // System.out.println("true");
            return date.before(expirDate);
        } catch (ParseException e) {
            return false;
        }
    }

    public void refundPayment(int ticket_ID) {
        Database database = new Database();
        database.refund(ticket_ID);
    }

}
