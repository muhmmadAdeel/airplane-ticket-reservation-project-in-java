
import java.awt.*;
import java.util.Scanner;
import javax.swing.*;

public class AdminServies {

    Scanner sc = new Scanner(System.in);
    public int Admin_ID;
    public String username;
    public String Admin_password;

    public AdminServies(int Admin_ID, String username, String password) {
        this.Admin_ID = Admin_ID;
        this.username = username;
        this.Admin_password = password;
    }

    public void AdminServiesGUI() {
        Flight flight = new Flight();
        JFrame adminFrame = new JFrame();
        adminFrame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        adminFrame.setSize(1000, 1000);
        adminFrame.setLayout(null);
        adminFrame.setLocationRelativeTo(null);

        JPanel AdminPanel = new JPanel();
        AdminPanel.setBounds(250, 70, 500, 500);
        AdminPanel.setLayout(null);
        AdminPanel.setBackground(new Color(0x154c79));

        JLabel welcome = new JLabel("Welcome " + username);
        welcome.setFont(new Font("Times New Roman", Font.BOLD, 30));
        welcome.setBounds(175, 10, 150, 50);
        welcome.setForeground(Color.white);

        JButton AddFlightButton = new JButton("Add new flight");
        AddFlightButton.setBounds(175, 60, 150, 50);
        AddFlightButton.setFocusable(false);
        AddFlightButton.addActionListener(event -> addFlightGUI());

        JButton ModifyFlightButton = new JButton("Modify flight");
        ModifyFlightButton.setBounds(175, 120, 150, 50);
        ModifyFlightButton.setFocusable(false);
        ModifyFlightButton.addActionListener(event -> ModifyFlightGUI());

        JButton DeleteFlightButton = new JButton("Delete flight");
        DeleteFlightButton.setBounds(175, 180, 150, 50);
        DeleteFlightButton.setFocusable(false);
        DeleteFlightButton.addActionListener(event -> deleteFlight());

        JButton ViewFlightButton = new JButton("View flights detail");
        ViewFlightButton.setBounds(175, 240, 150, 50);
        ViewFlightButton.setFocusable(false);
        ViewFlightButton.addActionListener(event -> flight.getFlightDetails(adminFrame));

        JButton updateProfileButton = new JButton("View profile");
        updateProfileButton.setBounds(175, 300, 150, 50);
        updateProfileButton.setFocusable(false);
        updateProfileButton.addActionListener(event -> modifyProfile());

        JButton logoutButton = new JButton("Logout");
        logoutButton.setBounds(175, 360, 150, 50);
        logoutButton.setFocusable(false);
        logoutButton.addActionListener(event -> {
            adminFrame.dispose();
        });

        AdminPanel.add(welcome);
        AdminPanel.add(AddFlightButton);
        AdminPanel.add(ModifyFlightButton);
        AdminPanel.add(DeleteFlightButton);
        AdminPanel.add(ViewFlightButton);
        AdminPanel.add(updateProfileButton);
        AdminPanel.add(logoutButton);
        adminFrame.add(AdminPanel);
        adminFrame.setLocationRelativeTo(null);
        adminFrame.setVisible(true);
    }

    public void addFlightGUI() {
        JFrame frameFlight = new JFrame();
        frameFlight.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        frameFlight.setSize(450, 600);
        frameFlight.setLocationRelativeTo(null);

        JPanel FlightPanel = new JPanel();
        FlightPanel.setLayout(null);

        JLabel fligt_ID_label = new JLabel("Enter Flight ID");
        fligt_ID_label.setBounds(75, 10, 200, 25);

        JTextField flightField = new JTextField();
        flightField.setBounds(75, 40, 200, 25);

        JLabel FlightNoLabel = new JLabel("Enter Flight Number");
        FlightNoLabel.setBounds(75, 70, 200, 25);

        JTextField flightNoField = new JTextField();
        flightNoField.setBounds(75, 100, 200, 25);

        JLabel departureLabel = new JLabel("Departure time");
        departureLabel.setBounds(75, 130, 200, 25);

        JTextField departurTextField = new JTextField("YYYY/MM/DD hh/MM AM");
        departurTextField.setBounds(75, 160, 200, 25);

        JLabel arriveLabel = new JLabel("Arrive time");
        arriveLabel.setBounds(75, 190, 200, 25);

        JTextField ArriveTextField = new JTextField("YYYY/MM/DD hh/MM AM");
        ArriveTextField.setBounds(75, 220, 200, 25);

        JLabel refundDatLabel = new JLabel("Enter refund last date");
        refundDatLabel.setBounds(75, 250, 200, 25);

        JTextField refundDateField = new JTextField("dd/MM/yyyy");
        refundDateField.setBounds(75, 280, 200, 25);
        

        JLabel OriginLabel = new JLabel("Enter Origin:");
        OriginLabel.setBounds(75, 310, 200, 25);

        JTextField OriginTextField = new JTextField();
        OriginTextField.setBounds(75, 340, 200, 25);

        JLabel destinationLabel = new JLabel("Enter destination:");
        destinationLabel.setBounds(75, 370, 200, 25);

        JTextField destinationTextField = new JTextField();
        destinationTextField.setBounds(75, 400, 200, 25);

        JLabel priceLabel = new JLabel("Enter price:");
        priceLabel.setBounds(75, 430, 200, 25);

        JTextField priceTextField = new JTextField();
        priceTextField.setBounds(75, 460, 200, 25);

        JButton submitButton = new JButton("Submit");
        submitButton.setBounds(75, 500, 100, 25);
        submitButton.setFocusable(false);
        submitButton.addActionListener(e -> {
            try {
                int Flight_ID = Integer.parseInt(flightField.getText());
                String Flight_No = flightNoField.getText();
                String Departure_time = departurTextField.getText();
                String Arrive_time = ArriveTextField.getText();
                String refundDate = refundDateField.getText();
                String Origin = OriginTextField.getText();
                String Destination = destinationTextField.getText();
                Double price = Double.parseDouble(priceTextField.getText());

                if (Flight_No.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Please enter Flight No");
                } else if (Departure_time.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Please enter Departure time");
                } else if (refundDate.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Please enter refund last date");
                }else if (Arrive_time.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Please enter Arrive time");
                } else if (Origin.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Please enter Origin");
                } else if (Destination.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Please enter Destination");
                } else if ((priceTextField.getText()).equals("")) {
                    JOptionPane.showMessageDialog(null, "Please enter price");
                } else {
                    frameFlight.dispose();
                    Flight flight = new Flight();
                    flight.addflight(Flight_ID, Flight_No, Departure_time, Arrive_time,refundDate, Origin, Destination,price);
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(null, "Please enter valid numerical values for Flight ID and Price");
            }
        });

        JButton cancelButton = new JButton("Cancel");
        cancelButton.setBounds(200, 500, 100, 25);
        cancelButton.setFocusable(false);
        cancelButton.addActionListener(e -> frameFlight.dispose());

        FlightPanel.add(fligt_ID_label);
        FlightPanel.add(flightField);
        FlightPanel.add(FlightNoLabel);
        FlightPanel.add(flightNoField);
        FlightPanel.add(departureLabel);
        FlightPanel.add(departurTextField);
        FlightPanel.add(arriveLabel);
        FlightPanel.add(ArriveTextField);
        FlightPanel.add(refundDatLabel);
        FlightPanel.add(refundDateField);
        FlightPanel.add(OriginLabel);
        FlightPanel.add(OriginTextField);
        FlightPanel.add(destinationLabel);
        FlightPanel.add(destinationTextField);
        FlightPanel.add(priceLabel);
        FlightPanel.add(priceTextField);
        FlightPanel.add(submitButton);
        FlightPanel.add(cancelButton);
        frameFlight.add(FlightPanel);
        frameFlight.setVisible(true);
    }
    public void ModifyFlightGUI() {
        JFrame modifyFrame;
        modifyFrame = new JFrame("Modify Flight");
        modifyFrame.setBounds(100, 100, 450, 450);
        modifyFrame.setLocationRelativeTo(null);
        modifyFrame.setLayout(null);
    
        String id = JOptionPane.showInputDialog(null, "Enter flight ID:");
        int flightID = Integer.parseInt(id);
        Database DB = new Database();
        int flag = DB.checkFlight(flightID);
        if (flag == 1) {
            JLabel lblFlightNumber = new JLabel("Flight Number:");
            lblFlightNumber.setBounds(50, 70, 100, 20);
            modifyFrame.add(lblFlightNumber);
    
            JTextField flightNumberField = new JTextField();
            flightNumberField.setBounds(200, 70, 200, 20);
            modifyFrame.add(flightNumberField);
    
            JLabel lblDepartureTime = new JLabel("Departure Time:");
            lblDepartureTime.setBounds(50, 110, 100, 20);
            modifyFrame.add(lblDepartureTime);
    
            JTextField departureTimeField = new JTextField("YYYY/MM/DD hh/MM AM");
            departureTimeField.setBounds(200, 110, 200, 20);
            modifyFrame.add(departureTimeField);
    
            JLabel lblArriveTime = new JLabel("Arrive Time:");
            lblArriveTime.setBounds(50, 150, 100, 20);
            modifyFrame.add(lblArriveTime);
    
            JTextField arriveTimeField = new JTextField("YYYY/MM/DD hh/MM AM");
            arriveTimeField.setBounds(200, 150, 200, 20);
            modifyFrame.add(arriveTimeField);

            JLabel refundDatLabel = new JLabel("Enter refund last date");
            refundDatLabel.setBounds(50, 190, 150, 20);
            modifyFrame.add(refundDatLabel);

            JTextField refundDateField = new JTextField("dd/MM/yyyy");
            refundDateField.setBounds(200, 190, 200, 20);
            modifyFrame.add(refundDateField);
    
            JLabel lblOrigin = new JLabel("Origin:");
            lblOrigin.setBounds(50, 230, 100, 20);
            modifyFrame.add(lblOrigin);
    
            JTextField originField = new JTextField();
            originField.setBounds(200, 230, 200, 20);
            modifyFrame.add(originField);
    
            JLabel lblDestination = new JLabel("Destination:");
            lblDestination.setBounds(50, 270, 100, 20);
            modifyFrame.add(lblDestination);
    
            JTextField destinationField = new JTextField();
            destinationField.setBounds(200, 270, 200, 20);
            modifyFrame.add(destinationField);
    
            JLabel lblPrice = new JLabel("Price:");
            lblPrice.setBounds(50, 320, 100, 20);
            modifyFrame.add(lblPrice);
    
            JTextField priceField = new JTextField();
            priceField.setBounds(200, 320, 200, 20);
            modifyFrame.add(priceField);
    
            JButton btnModify = new JButton("Modify Flight");
            btnModify.setBounds(70, 360, 150, 30);
            modifyFrame.add(btnModify);
    
            btnModify.addActionListener(e -> {
                String flightNumber = flightNumberField.getText();
                String departureTime = departureTimeField.getText();
                String arriveTime = arriveTimeField.getText();
                String refundDate = refundDateField.getText();
                String origin = originField.getText();
                String destination = destinationField.getText();
                double price = Double.parseDouble(priceField.getText());
                if (flightNumber.isEmpty()) {
                    JOptionPane.showMessageDialog(modifyFrame, "Please enter Flight No");
                } else if (departureTime.isEmpty()) {
                    JOptionPane.showMessageDialog(modifyFrame, "Please enter Departure time");
                } else if (arriveTime.isEmpty()) {
                    JOptionPane.showMessageDialog(modifyFrame, "Please enter Arrive time");
                } else if(refundDate.isEmpty()){
                    JOptionPane.showMessageDialog(modifyFrame, "Please enter refund last date");
                } else if (origin.isEmpty()) {
                    JOptionPane.showMessageDialog(modifyFrame, "Please enter Origin");
                } else if (destination.isEmpty()) {
                    JOptionPane.showMessageDialog(modifyFrame, "Please enter Destination");
                } else if (priceField.getText().equals("")) {
                    JOptionPane.showMessageDialog(modifyFrame, "Please enter price");
                } else {
                    modifyFrame.dispose();
                    Flight flight = new Flight();
                    flight.updateFlight(flightID, flightNumber, departureTime, arriveTime,refundDate, origin, destination, price);
                }
            });
    
            JButton btnCancel = new JButton("Cancel");
            btnCancel.setBounds(240, 360, 150, 30);
            modifyFrame.add(btnCancel);
            btnCancel.addActionListener(e -> modifyFrame.dispose());
    
            modifyFrame.setVisible(true);
        } else {
            JOptionPane.showMessageDialog(null, "Flight ID does not exist!");
        }
    }
    

    public void deleteFlight() {
        Flight flight = new Flight();
        flight.deleteFlight();
    }

    public void modifyProfile() {
        JFrame ProfileFrame = new JFrame();
        ProfileFrame.setSize(400, 400);
        ProfileFrame.setLayout(null);
        ProfileFrame.setLocationRelativeTo(null);

        JLabel adminIdLabel = new JLabel(" ID         :" + Admin_ID);
        adminIdLabel.setBounds(10, 20, 200, 25);
        ProfileFrame.add(adminIdLabel);

        JLabel usernameLabel = new JLabel("Username   :" + username);
        usernameLabel.setBounds(10, 50, 200, 25);
        ProfileFrame.add(usernameLabel);

        JLabel passwordLabel = new JLabel("Password   :" + Admin_password);
        passwordLabel.setBounds(10, 80, 200, 25);
        ProfileFrame.add(passwordLabel);

        JButton changePassButton = new JButton("Change Password");
        changePassButton.setBounds(10, 110, 150, 25);
        ProfileFrame.add(changePassButton);
        changePassButton.addActionListener(e -> {
            String newPassword = JOptionPane.showInputDialog(ProfileFrame, "Enter new Password");
            if (newPassword.isEmpty()) {
                JOptionPane.showMessageDialog(ProfileFrame, "Password not changed");
            } else {
                ProfileFrame.dispose();
                Database db = new Database();
                Admin_password = db.adminpasswordChange(Admin_ID, newPassword, ProfileFrame);
            }
        });

        JButton cancelButton = new JButton("Cancel");
        cancelButton.setBounds(170, 110, 150, 25);
        ProfileFrame.add(cancelButton);
        cancelButton.addActionListener(e -> ProfileFrame.dispose());

        ProfileFrame.setVisible(true);
    }

}
