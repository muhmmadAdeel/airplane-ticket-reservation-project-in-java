
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.util.Scanner;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class Database {

    Scanner sc = new Scanner(System.in);
    private static final String DB_URL = "jdbc:mysql://localhost:3306/online_issue_ticket";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "Adeel16616@!@";

    public Database() {
    }

    public Database(String e) {

        JFrame main_frame = new JFrame();
        main_frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        main_frame.setSize(1000, 1000);
        main_frame.setLayout(null);

        JPanel panel = new JPanel();
        panel.setBounds(300, 100, 400, 500);
        panel.setLayout(null);
        panel.setBackground(new Color(0xFF7F99));

        JButton adminLoginButton = new JButton("Admin Login");
        adminLoginButton.setBounds(125, 80, 150, 50);
        adminLoginButton.setFocusable(false);
        adminLoginButton.addActionListener(event -> adminGUI(1));
        JButton userLoginButton = new JButton("User Login");
        userLoginButton.setBounds(125, 150, 150, 50);
        userLoginButton.setFocusable(false);
        userLoginButton.addActionListener(event -> adminGUI(2));
        JButton userSignupButton = new JButton("User Sign Up");
        userSignupButton.setBounds(125, 220, 150, 50);
        userSignupButton.setFocusable(false);
        userSignupButton.addActionListener(event -> userSignUpGUI());
        JButton logoutButton = new JButton("Logout");
        logoutButton.setBounds(125, 290, 150, 50);
        logoutButton.setFocusable(false);
        logoutButton.addActionListener(event -> {
            main_frame.dispose();
        });
        panel.add(adminLoginButton);
        panel.add(userLoginButton);
        panel.add(userSignupButton);
        panel.add(logoutButton);

        main_frame.add(panel);
        main_frame.setLocationRelativeTo(null);
        main_frame.setVisible(true);
    }

    public static void adminGUI(int i) {
        JFrame frame = new JFrame();
        frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        frame.setSize(400, 300);

        JPanel panel = new JPanel();
        panel.setLayout(null);

        JLabel usernameLabel = new JLabel("Username or Email ");
        usernameLabel.setBounds(75, 10, 200, 25);
        JTextField usernameField = new JTextField();
        usernameField.setBounds(75, 40, 215, 25);

        JLabel passLabel = new JLabel("Password:");
        passLabel.setBounds(75, 70, 100, 25);
        JPasswordField passwordField = new JPasswordField();
        passwordField.setBounds(75, 90, 215, 25);

        JButton loginButton = new JButton("Login");
        loginButton.setBounds(75, 130, 100, 25);

        JButton cancelButton = new JButton("cancel");
        cancelButton.setBounds(190, 130, 100, 25);

        cancelButton.addActionListener(event -> frame.dispose());
        loginButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String username = usernameField.getText();
                String password = new String(passwordField.getPassword());
                if (username.equals("")) {
                    JOptionPane.showMessageDialog(null, "PLease enter username !");

                } else if (password.equals("")) {
                    JOptionPane.showMessageDialog(null, "Please enter password !");
                } else if (username.equals("") && username.equals("")) {
                    JOptionPane.showMessageDialog(null, "Please enter username and password !");
                } else {
                    if (i == 1) {
                        // frame.dispose();
                        adminLogin(username, password, frame);
                    }
                    if (i == 2) {
                        login_user(username, password, frame);
                    }
                }
            }
        });
        panel.add(usernameLabel);
        panel.add(usernameField);
        panel.add(passLabel);
        panel.add(passwordField);
        panel.add(loginButton);
        panel.add(cancelButton);
        frame.add(panel);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

    public static void userSignUpGUI() {
        JFrame frame = new JFrame();
        frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        frame.setSize(400, 400);

        JPanel panel = new JPanel();
        panel.setLayout(null);

        JLabel emailLabel = new JLabel("Email ");
        emailLabel.setBounds(75, 10, 200, 25);
        JTextField emailField = new JTextField();
        emailField.setBounds(75, 40, 215, 25);

        JLabel PhoneNoLabel = new JLabel("Phone Number:");
        PhoneNoLabel.setBounds(75, 70, 100, 25);
        JTextField PhoneNoField = new JTextField();
        PhoneNoField.setBounds(75, 90, 215, 25);

        JLabel usernameLabel = new JLabel("Username");
        usernameLabel.setBounds(75, 130, 100, 25);
        JTextField usernameField = new JTextField();
        usernameField.setBounds(75, 150, 215, 25);

        JLabel passwordLabel = new JLabel("Password");
        passwordLabel.setBounds(75, 190, 100, 25);
        JPasswordField passwordField = new JPasswordField();
        passwordField.setBounds(75, 210, 215, 25);

        JButton loginButton = new JButton("sign up");
        loginButton.setBounds(75, 250, 100, 25);

        JButton cancelButton = new JButton("cancel");
        cancelButton.setBounds(190, 250, 100, 25);

        cancelButton.addActionListener(event -> frame.dispose());
        loginButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String email = emailField.getText();
                String PhoneNo = PhoneNoField.getText();
                String username = usernameField.getText();
                String password = new String(passwordField.getPassword());
                if (email.equals("")) {
                    JOptionPane.showMessageDialog(null, "PLease enter Email !");
                } else if (PhoneNo.equals("")) {
                    JOptionPane.showMessageDialog(null, "PLease enter Phone No !");
                } else if (username.equals("")) {
                    JOptionPane.showMessageDialog(null, "PLease enter username !");

                } else if (password.equals("")) {
                    JOptionPane.showMessageDialog(null, "Please enter password !");
                } else {
                    frame.dispose();
                    user_sign_up(email, PhoneNo, username, password);
                }
            }
        });
        panel.add(emailLabel);
        panel.add(emailField);
        panel.add(PhoneNoLabel);
        panel.add(PhoneNoField);
        panel.add(usernameLabel);
        panel.add(usernameField);
        panel.add(passwordLabel);
        panel.add(passwordField);
        panel.add(loginButton);
        panel.add(cancelButton);
        frame.add(panel);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

    public static void adminLogin(String admin_username, String Admin_password, JFrame adminFrame) {

        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD); Statement statement = connection.createStatement(); ResultSet resultSet = statement.executeQuery("SELECT admin_id,username,email, admin_password FROM adminLogin")) {
            boolean flag = true;
            while (resultSet.next()) {
                int admin_id = resultSet.getInt("admin_id");
                String username_DB = resultSet.getString("username");
                String email_DB = resultSet.getString("email");
                String adminPassword_DB = resultSet.getString("admin_password");

                if (admin_username.equals(username_DB) && Admin_password.equals(adminPassword_DB) || admin_username.equals(email_DB) && Admin_password.equals(adminPassword_DB)) {
                    flag = false;
                    JOptionPane.showMessageDialog(adminFrame, "Successfully logged in", "Login", JOptionPane.INFORMATION_MESSAGE);
                    adminFrame.dispose();
                    AdminServies adminServies = new AdminServies(admin_id, username_DB, adminPassword_DB);
                    adminServies.AdminServiesGUI();
                }
            }
            if (flag) {
                JOptionPane.showMessageDialog(adminFrame, "Invalid username or password");
                // adminGUI(1);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex);
        }
    }

    public static void login_user(String username, String password, JFrame loginFrame) {

        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD); Statement statement = connection.createStatement(); ResultSet resultSet = statement.executeQuery("SELECT user_ID,username, user_password, email FROM t_customer")) {
            boolean flag = true;
            while (resultSet.next()) {
                int user_ID = resultSet.getInt("user_ID");
                String Db_username = resultSet.getString("username");
                String Db_email = resultSet.getString("email");
                String Db_password = resultSet.getString("user_password");

                if ((username.equals(Db_username) && password.equals(Db_password)) || (username.equals(Db_email) && password.equals(Db_password))) {
                    flag = false;
                    JOptionPane.showMessageDialog(loginFrame, "Successfully logged in", "Login", JOptionPane.INFORMATION_MESSAGE);
                    loginFrame.dispose();
                    customer customer1 = new customer();
                    customer1.login(user_ID, Db_username, password);
                    customer1.customerMenuGUI();
                    break;
                }
            }
            if (flag) {
                JOptionPane.showMessageDialog(loginFrame, "Invalid username or password");
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error " + ex);
        }
    }

    public static void user_sign_up(String email, String phoneNo, String username, String password) {

        String sql = "INSERT INTO t_customer (email, phone_no, username, user_password) VALUES (?, ?, ?, ?)";
        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD); PreparedStatement statement = connection.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS)) {
            statement.setString(1, email);
            statement.setString(2, phoneNo);
            statement.setString(3, username);
            statement.setString(4, password);
            int rowsInserted = statement.executeUpdate();
            if (rowsInserted > 0) {
                try (ResultSet generatedKeys = statement.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        int generatedId = generatedKeys.getInt(1);
                        customer user = new customer();
                        user.register(generatedId, email, phoneNo, username, password);
                        JOptionPane.showMessageDialog(null, "Successfully sign up", "SignUp", JOptionPane.INFORMATION_MESSAGE);
                        user.customerMenuGUI();
                    }
                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(null, ex);
                }
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error " + ex);
        }
    }

    public void add_flight_in_sql(int Flight_ID, String Flight_No, String Departure_time, String Arrive_time,String refundDate, String Origen, String destination, double price) {
        String sql = "INSERT INTO t_flight (flight_ID, Flight_No, Departure_time, Arrive_time,refundDate, Origin,destination,price) VALUES (?, ?, ?, ?, ?, ?,?,?)";

        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD); PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setInt(1, Flight_ID);
            statement.setString(2, Flight_No);
            statement.setString(3, Departure_time);
            statement.setString(4, Arrive_time);
            statement.setString(5, refundDate);
            statement.setString(6, Origen);
            statement.setString(7, destination);
            statement.setDouble(8, price);

            int rowsInserted = statement.executeUpdate();
            if (rowsInserted > 0) {
                JOptionPane.showMessageDialog(null, "Flight record added successfully!");
            } else {
                JOptionPane.showMessageDialog(null, "Error: No flight added");
            }

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "error found " + ex.getMessage());
        }
    }

    public void Modify_flight_in_sql(int flight_id, String Flight_No, String Departure_time, String Arrive_time,String refundDate, String Origen, String destination, double price) {
        String sql = "UPDATE t_flight SET Flight_No = ?, Departure_time = ?, Arrive_time = ?,refundDate = ? , Origin = ? ,destination = ?, price = ? WHERE flight_ID = ?";

        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD); PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setString(1, Flight_No);
            statement.setString(2, Departure_time);
            statement.setString(3, Arrive_time);
            statement.setString(4, refundDate);
            statement.setString(5, Origen);
            statement.setString(6, destination);
            statement.setDouble(7, price);
            statement.setInt(8, flight_id);
            int rowsUpdated = statement.executeUpdate();
            if (rowsUpdated > 0) {
                JOptionPane.showMessageDialog(null, "Updated successfully");
            } else {
                JOptionPane.showMessageDialog(null, "No flight found with the provided details");
            }

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error " + ex);
        }
    }

    public void delete_flight_from_sql(int flight_ID, String flight_No) {
        String payment_sql = "DELETE FROM t_payment WHERE flight_id = ?";
        String booking_Sql = "DELETE FROM t_booking WHERE flight_id = ?";
        String sql = "DELETE FROM t_flight WHERE flight_id = ? AND flight_no = ?";
        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD); PreparedStatement statement = connection.prepareStatement(payment_sql)) {
            statement.setInt(1, flight_ID);
            statement.executeUpdate();

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error " + ex);
        }

        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD); PreparedStatement statement = connection.prepareStatement(booking_Sql)) {
            statement.setInt(1, flight_ID);
            statement.executeUpdate();

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error " + ex);
        }

        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD); PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setInt(1, flight_ID);
            statement.setString(2, flight_No);

            int rowsDeleted = statement.executeUpdate();
            if (rowsDeleted > 0) {
                // System.out.println("Flight record deleted successfully!");
                JOptionPane.showMessageDialog(null, "Flight record deleted successfully");
            } else {
                JOptionPane.showMessageDialog(null, "No flight found with the provided details");
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error " + ex);
        }
    }

    public void show_flight_details(int flight_ID, JFrame frame) {
        String sql = "SELECT * FROM t_flight WHERE flight_ID = ?";

        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD); PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, flight_ID);
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    int id = resultSet.getInt("flight_ID");
                    String flightNo = resultSet.getString("Flight_No");
                    String departureTime = resultSet.getString("Departure_time");
                    String arriveTime = resultSet.getString("Arrive_time");
                    String origin = resultSet.getString("Origin");
                    String destination = resultSet.getString("destination");
                    double price = resultSet.getDouble("price");

                    JOptionPane.showMessageDialog(frame, "Flight ID     :" + id + "\nFlight No     :" + flightNo + "\nDeparture Time     :" + departureTime + "\nArrive Time     :" + arriveTime + "\nOrigin     :" + origin + "\nDestination     :" + destination + "\nPrice     :" + price);
                } else {
                    JOptionPane.showMessageDialog(frame, "No flight found with the provided ID");
                }
            }

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(frame, "Error " + ex);
        }
    }

    public String adminpasswordChange(int adminID, String pass, JFrame frame) {
        String sql = "UPDATE adminLogin SET admin_password = ? WHERE admin_id = ?";

        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD); PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setString(1, pass);
            statement.setInt(2, adminID);
            int rowsUpdated = statement.executeUpdate();
            if (rowsUpdated > 0) {
                JOptionPane.showMessageDialog(frame, "Password successfully changed");
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(frame, "Error " + ex);
        }

        return pass;
    }

    public void show_flight_details_for_customer(JFrame showFrame) {
        String sql = "SELECT * FROM t_flight ";

        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD); PreparedStatement statement = connection.prepareStatement(sql)) {
            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    int id = resultSet.getInt("flight_ID");
                    String flightNo = resultSet.getString("Flight_No");
                    String departureTime = resultSet.getString("Departure_time");
                    String arriveTime = resultSet.getString("Arrive_time");
                    String origin = resultSet.getString("Origin");
                    String destination = resultSet.getString("destination");
                    double price = resultSet.getDouble("price");
                    JOptionPane.showMessageDialog(showFrame, "Flight ID     :" + id + "\nFlight No     :" + flightNo + "\nDeparture time   :" + departureTime + "\nArrive time   :" + arriveTime + "\nOrigin     :" + origin + "\ndestination   :" + destination + "\nPrice     :" + price);
                }
            }

        } catch (SQLException ex) {
            System.out.println("Error: " + ex.getMessage());
        }
    }

    public void create_Booking(int user_ID, int flight_ID, String status) {
        String sql = "INSERT INTO t_booking (user_ID, flight_ID, booking_status) VALUES ( ?, ?, ?)";
        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD); PreparedStatement statement = connection.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS)) {

            statement.setInt(1, user_ID);
            statement.setInt(2, flight_ID);
            statement.setString(3, status);
            int rowsInserted = statement.executeUpdate();

            if (rowsInserted > 0) {
                try (ResultSet generatedKeys = statement.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        int booking_ID = generatedKeys.getInt(1);

                        String get_priceSql = "SELECT t_flight.price FROM t_flight WHERE flight_id = ?";
                        try (PreparedStatement priceStatement = connection.prepareStatement(get_priceSql)) {
                            priceStatement.setInt(1, flight_ID);
                            try (ResultSet priceResultSet = priceStatement.executeQuery()) {
                                if (priceResultSet.next()) {
                                    double price = priceResultSet.getDouble("price");
                                    String paymentSql = "INSERT INTO t_payment (user_id,flight_id, booking_id, price) VALUES (?,?, ?, ?)";
                                    try (PreparedStatement payStatement = connection.prepareStatement(paymentSql)) {
                                        payStatement.setInt(1, user_ID);
                                        payStatement.setInt(2, flight_ID);
                                        payStatement.setInt(3, booking_ID);
                                        payStatement.setDouble(4, price);
                                        payStatement.executeUpdate();
                                    }
                                }
                            }
                        }
                        String ticketDetailsSql = "SELECT t_booking.booking_ID, t_booking.flight_ID, t_flight.Departure_time, t_flight.Arrive_time, t_flight.Origin, t_flight.Destination "
                                + "FROM t_booking "
                                + "JOIN t_flight ON t_booking.flight_ID = t_flight.flight_ID "
                                + "WHERE t_booking.booking_ID = ?";
                        try (PreparedStatement ticketStatement = connection.prepareStatement(ticketDetailsSql)) {
                            ticketStatement.setInt(1, booking_ID);
                            try (ResultSet ticketResultSet = ticketStatement.executeQuery()) {
                                if (ticketResultSet.next()) {
                                    int ticketID = ticketResultSet.getInt("booking_ID");
                                    int bookedFlightID = ticketResultSet.getInt("flight_ID");
                                    String departureTime = ticketResultSet.getString("Departure_time");
                                    String arriveTime = ticketResultSet.getString("Arrive_time");
                                    String origin = ticketResultSet.getString("Origin");
                                    String destination = ticketResultSet.getString("Destination");
                                    // System.out.println("Booking Receipt:");
                                    // System.out.println("Ticket ID: " + ticketID);
                                    // System.out.println("Flight ID: " + bookedFlightID);
                                    // System.out.println("Departure Time: " + departureTime);
                                    // System.out.println("Arrival Time: " + arriveTime);
                                    // System.out.println("Origin: " + origin);
                                    // System.out.println("Destination: " + destination);

                                    JTextArea textArea = new JTextArea();
                                    textArea.setEditable(false);
                                    textArea.setText("Booking Receipt:\n");
                                    textArea.append("Ticket ID: " + ticketID + "\n");
                                    textArea.append("Flight ID: " + bookedFlightID + "\n");
                                    textArea.append("Departure Time: " + departureTime + "\n");
                                    textArea.append("Arrival Time: " + arriveTime + "\n");
                                    textArea.append("Origin: " + origin + "\n");
                                    textArea.append("Destination: " + destination + "\n");

                                    JScrollPane scrollPane = new JScrollPane(textArea);
                                    scrollPane.setPreferredSize(new java.awt.Dimension(300, 200));

                                    JOptionPane.showMessageDialog(null, scrollPane, "Booking Receipt", JOptionPane.INFORMATION_MESSAGE);

                                } else {
                                    JOptionPane.showMessageDialog(null, "error please try again");
                                }
                            }
                        }
                    }
                }
            } else {
                JOptionPane.showMessageDialog(null, "cancel booking");
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "error :" + ex);
        }
    }

    public void cancelTicket(int booking_ID) {
        String sql = "DELETE FROM t_booking WHERE booking_id = ?";

        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD); PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setInt(1, booking_ID);
            int rowsDeleted = statement.executeUpdate();

            if (rowsDeleted > 0) {
                // System.out.println("Flight cancelled successfully.");
                JOptionPane.showMessageDialog(null, "Flight cancelled successfully");
            } else {
                // System.out.println("No booking found with the provided ID.");
                JOptionPane.showMessageDialog(null, "No booking found with the provided ID");
            }

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "error :" + ex);
        }
    }

    public void user_viewProfile(int user_ID, JFrame profileFrame) {
        String sql = "SELECT * FROM t_customer WHERE user_ID = ?";

        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD); PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setInt(1, user_ID);

            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    int id = resultSet.getInt("user_id");
                    String email = resultSet.getString("email");
                    String phoneNo = resultSet.getString("phone_no");
                    String username = resultSet.getString("username");
                    String password = resultSet.getString("user_password");
                    JOptionPane.showMessageDialog(profileFrame, "Customer ID     :" + id + "\nEmail     :" + email + "\nPhone Number      :" + phoneNo + "\nUsername     :" + username + "\nPassword     : " + password);
                } else {
                    JOptionPane.showMessageDialog(profileFrame, "Not found provided ID");

                }
            }

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(profileFrame, "error :" + ex);
        }
    }

    public void user_modifyProfile(int id, String email, String phone_no, String username, String password, JFrame modifyFrame) {

        String sql = "UPDATE t_customer SET email = ?, phone_no = ?, username = ?, user_password = ? WHERE user_ID = ?";

        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD); PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setString(1, email);
            statement.setString(2, phone_no);
            statement.setString(3, username);
            statement.setString(4, password);
            statement.setInt(5, id);

            int rowsUpdated = statement.executeUpdate();
            if (rowsUpdated > 0) {
                // System.out.println("Profile updated successfully.");
                JOptionPane.showMessageDialog(modifyFrame, "Profile Updated successfully");
                modifyFrame.dispose();
            } else {
                // System.out.println("Error: No user found with the provided ID.");
                JOptionPane.showMessageDialog(modifyFrame, "Not found provided ID");
            }

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(modifyFrame, "error :" + ex);
        }
    }

    public void refund(int booking_ID) {
        String selectFlightSql = "SELECT flight_id FROM t_payment WHERE booking_id = ?";

        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD); PreparedStatement selectFlightStatement = connection.prepareStatement(selectFlightSql)) {
            selectFlightStatement.setInt(1, booking_ID);
            try (ResultSet resultSet = selectFlightStatement.executeQuery()) {
                if (resultSet.next()) {
                    int flight_ID = resultSet.getInt("flight_id");

                    String getPriceSql = "SELECT price, refundDate FROM t_flight WHERE flight_id = ?";
                    try (PreparedStatement priceStatement = connection.prepareStatement(getPriceSql)) {
                        priceStatement.setInt(1, flight_ID);
                        try (ResultSet priceResultSet = priceStatement.executeQuery()) {
                            if (priceResultSet.next()) {
                                double price = priceResultSet.getDouble("price");
                                String refundDate = priceResultSet.getString("refundDate");

                                Payment payment = new Payment();
                                if (payment.verifyPayment(refundDate)) {
                                    // System.out.println("We will process your refund within 24 hours. Amount: " + price);
                                    JOptionPane.showMessageDialog(null, "We will process your refund within 24 hours. Amount:" + price);

                                    String paymentSql = "DELETE FROM t_payment WHERE booking_id = ?";
                                    try (PreparedStatement payStatement = connection.prepareStatement(paymentSql)) {
                                        payStatement.setInt(1, booking_ID);
                                        payStatement.executeUpdate();
                                    }

                                    Booking booking = new Booking();
                                    booking.cancelBooking(booking_ID);
                                } else {
                                    // System.out.println("You are not eligible for a refund.");
                                    JOptionPane.showMessageDialog(null, "You are not eligible for a refund");
                                }
                            }
                        }
                    }
                } else {
                    // System.out.println("No booking found with the provided ID.");
                    JOptionPane.showMessageDialog(null, "No booking found with the provided ID");
                }
            }

        } catch (SQLException ex) {
            // System.out.println("Error: " + ex.getMessage());
            JOptionPane.showMessageDialog(null, "error" + ex);
        }
    }

    public int checkFlight(int flight_ID) {
        String sql = "select flight_id from t_flight where flight_id = ?";
        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD); PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, flight_ID);
            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    if (flight_ID == resultSet.getInt("flight_ID")) {
                        return 1;
                    }
                }
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "error found :" + ex);
        }
        return 0;
    }
}
