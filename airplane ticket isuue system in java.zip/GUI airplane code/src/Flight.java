
import java.util.Scanner;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class Flight {

    Database db = new Database();

    public void addflight(int Flight_ID, String Flight_No, String Departure_time, String Arrive_time, String refundDate, String Origen, String destination, double price) {
        db.add_flight_in_sql(Flight_ID, Flight_No, Departure_time, Arrive_time, refundDate, Origen, destination, price);
    }

    public void updateFlight(int Flight_ID, String Flight_No, String Departure_time, String Arrive_time, String refundDate, String Origen, String destination, double price) {
        db.Modify_flight_in_sql(Flight_ID, Flight_No, Departure_time, Arrive_time, refundDate, Origen, destination, price);
    }
    Scanner sc = new Scanner(System.in);

    public void getFlightDetails(JFrame frame) {
        int flight_id = Integer.parseInt(JOptionPane.showInputDialog("Enter flight ID"));
        db.show_flight_details(flight_id, frame);
    }

    public void deleteFlight() {
        JFrame deleteFrame = new JFrame();
        deleteFrame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        deleteFrame.setSize(300, 300);
        deleteFrame.setLayout(null);

        JLabel flightIdLabel = new JLabel("Enter flight ID");
        flightIdLabel.setBounds(50, 30, 200, 25);
        deleteFrame.add(flightIdLabel);
        JTextField flighTextField = new JTextField();
        flighTextField.setBounds(50, 60, 200, 25);
        deleteFrame.add(flighTextField);

        JLabel flightNOLabel = new JLabel("Enter flight number ");
        flightNOLabel.setBounds(50, 90, 200, 25);
        deleteFrame.add(flightNOLabel);
        JTextField FlightNoField = new JTextField();
        FlightNoField.setBounds(50, 120, 200, 25);
        deleteFrame.add(FlightNoField);

        JButton submiButton = new JButton("Submit");
        submiButton.setBounds(50, 150, 90, 25);
        submiButton.setFocusable(false);
        deleteFrame.add(submiButton);

        JButton cancelButton = new JButton("Cancel");
        cancelButton.setBounds(150, 150, 90, 25);
        cancelButton.setFocusable(false);
        deleteFrame.add(cancelButton);
        cancelButton.addActionListener(e -> deleteFrame.dispose());

        submiButton.addActionListener(e -> {
            int Flight_id = Integer.parseInt(flighTextField.getText());
            String Flight_No = flighTextField.getText();
            if (flighTextField.getText().isEmpty()) {
                JOptionPane.showMessageDialog(deleteFrame, "Please enter flight ID");
            } else if (Flight_No.isEmpty()) {
                JOptionPane.showMessageDialog(deleteFrame, "Please enter flight number");
            } else {
                deleteFrame.dispose();
                db.delete_flight_from_sql(Flight_id, Flight_No);
            }
        });

        deleteFrame.setLocationRelativeTo(null);
        deleteFrame.setVisible(true);

    }
}
