
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Scanner;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class customer {

    public int customer_id;
    public String email;
    public String Phone_No;
    public String username;
    public String user_password;
    Database database = new Database();
    Scanner sc = new Scanner(System.in);

    public void register(int id, String email, String Phone_No, String username, String password) {
        this.email = email;
        this.Phone_No = Phone_No;
        this.username = username;
        this.user_password = password;
        this.customer_id = id;
    }

    public void login(int user_id, String username, String password) {
        this.customer_id = user_id;
        this.username = username;
        this.user_password = password;
    }

    public void customerMenuGUI() {
        JFrame customerFrame = new JFrame();
        customerFrame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        customerFrame.setSize(600, 600);
        customerFrame.setLocationRelativeTo(null);

        JPanel CustomerPanel = new JPanel();
        CustomerPanel.setBounds(250, 70, 500, 500);
        CustomerPanel.setLayout(null);
        CustomerPanel.setBackground(new Color(0x154c79));

        JLabel welcome = new JLabel("Welcome " + this.username);
        welcome.setFont(new Font("Times New Roman", Font.BOLD, 30));
        welcome.setBounds(175, 10, 150, 50);
        welcome.setForeground(Color.white);
        CustomerPanel.add(welcome);

        JButton bookTicketButton = new JButton("Book ticket");
        bookTicketButton.setBounds(175, 60, 150, 50);
        bookTicketButton.setFocusable(false);
        bookTicketButton.addActionListener(event -> BookTicket(this.customer_id, customerFrame));
        CustomerPanel.add(bookTicketButton);

        JButton cancelTicketButton = new JButton("cancel ticket");
        cancelTicketButton.setBounds(175, 120, 150, 50);
        cancelTicketButton.setFocusable(false);
        cancelTicketButton.addActionListener(event -> cancelTicket(customerFrame));
        CustomerPanel.add(cancelTicketButton);

        JButton viewTicketButton = new JButton("view tickets");
        viewTicketButton.setBounds(175, 180, 150, 50);
        viewTicketButton.setFocusable(false);
        viewTicketButton.addActionListener(event -> viewFlight(customerFrame));
        CustomerPanel.add(viewTicketButton);

        JButton ViewProfileButton = new JButton("view profile");
        ViewProfileButton.setBounds(175, 240, 150, 50);
        ViewProfileButton.setFocusable(false);
        ViewProfileButton.addActionListener(event -> viewProfile(customerFrame));
        CustomerPanel.add(ViewProfileButton);

        JButton updateProfileButton = new JButton("Modify profile");
        updateProfileButton.setBounds(175, 300, 150, 50);
        updateProfileButton.setFocusable(false);
        updateProfileButton.addActionListener(event -> modifyProfile());
        CustomerPanel.add(updateProfileButton);

        JButton logoutButton = new JButton("Logout");
        logoutButton.setBounds(175, 360, 150, 50);
        logoutButton.setFocusable(false);
        logoutButton.addActionListener(event -> {
            customerFrame.dispose();
        });
        CustomerPanel.add(logoutButton);

        customerFrame.add(CustomerPanel);
        customerFrame.setVisible(true);

    }

    public void viewFlight(JFrame frame) {
        database.show_flight_details_for_customer(frame);

    }

    public void BookTicket(int user_ID, JFrame frame) {
        String flight_id = JOptionPane.showInputDialog(frame, "Enter flight ID :");
        if (flight_id.equals("")) {
            JOptionPane.showMessageDialog(frame, "Please enter flight ID");
        } else {
            int flightID = Integer.parseInt(flight_id);
            if (flightID >= 0) {
                Payment payment = new Payment();
                payment.processPayment(user_ID, flightID);
            }
        }
    }

    public void cancelTicket(JFrame cancelFrame) {
        String ticketID = JOptionPane.showInputDialog(cancelFrame, "Enter ticket ID");
        if (ticketID != null && !ticketID.isEmpty()) {
            int ticket_ID = Integer.parseInt(ticketID);
            if (ticket_ID >= 0) {
                Payment payment = new Payment();
                payment.refundPayment(ticket_ID);
            } else {
                JOptionPane.showMessageDialog(cancelFrame, "Invalid ticket id !");
            }
        }
    }

    public void viewProfile(JFrame profileFrame) {
        database.user_viewProfile(customer_id, profileFrame);
    }

    public void modifyProfile() {

        // System.out.println("Enter ID ");
        // int id = sc.nextInt();
        // sc.nextLine();
        // System.out.println("Enter Email ");
        // String new_email = sc.nextLine();
        // System.out.println("Enter Phone number ");
        // String new_phoneNo = sc.nextLine();
        // System.out.println("Enter username ");
        // String new_username = sc.nextLine();
        // System.out.println("Enter Password ");
        // String new_password = sc.nextLine();
        // System.out.println("are you confirm :(1/0)");
        // int ch = sc.nextInt();
        // if (ch == 1) {
        //     database.user_modifyProfile(id, new_email, new_phoneNo, new_username, new_password,frame);
        // } else {
        //     System.out.println("cancelled ");
        // }
        JFrame frame = new JFrame();
        frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        frame.setSize(400, 400);

        JPanel panel = new JPanel();
        panel.setLayout(null);

        JLabel idLabel = new JLabel("ID ");
        idLabel.setBounds(75, 10, 200, 25);
        JTextField iField = new JTextField();
        iField.setBounds(75, 30, 215, 25);

        JLabel emailLabel = new JLabel("Email ");
        emailLabel.setBounds(75, 70, 200, 25);
        JTextField emailField = new JTextField();
        emailField.setBounds(75, 90, 215, 25);

        JLabel PhoneNoLabel = new JLabel("Phone Number:");
        PhoneNoLabel.setBounds(75, 130, 100, 25);
        JTextField PhoneNoField = new JTextField();
        PhoneNoField.setBounds(75, 150, 215, 25);

        JLabel usernameLabel = new JLabel("Username");
        usernameLabel.setBounds(75, 190, 100, 25);
        JTextField usernameField = new JTextField();
        usernameField.setBounds(75, 210, 215, 25);

        JLabel passwordLabel = new JLabel("Password");
        passwordLabel.setBounds(75, 250, 100, 25);
        JPasswordField passwordField = new JPasswordField();
        passwordField.setBounds(75, 270, 215, 25);

        JButton loginButton = new JButton("sign up");
        loginButton.setBounds(75, 310, 100, 25);

        JButton cancelButton = new JButton("cancel");
        cancelButton.setBounds(190, 310, 100, 25);

        cancelButton.addActionListener(event -> frame.dispose());
        loginButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String getID = iField.getText();
                String new_email = emailField.getText();
                String new_phoneNo = PhoneNoField.getText();
                String new_username = usernameField.getText();
                String new_password = new String(passwordField.getPassword());
                if (new_email.equals("")) {
                    JOptionPane.showMessageDialog(frame, "PLease enter Email !");
                } else if (getID.equals("")) {
                    JOptionPane.showMessageDialog(frame, "PLease enter user ID !");
                } else if (new_phoneNo.equals("")) {
                    JOptionPane.showMessageDialog(frame, "PLease enter Phone No !");
                } else if (new_username.equals("")) {
                    JOptionPane.showMessageDialog(frame, "PLease enter username !");
                } else if (new_password.equals("")) {
                    JOptionPane.showMessageDialog(frame, "Please enter password !");
                } else {
                    int id = Integer.parseInt(getID);
                    database.user_modifyProfile(id, new_email, new_phoneNo, new_username, new_password, frame);
                }
            }
        });
        panel.add(idLabel);
        panel.add(iField);
        panel.add(emailLabel);
        panel.add(emailField);
        panel.add(PhoneNoLabel);
        panel.add(PhoneNoField);
        panel.add(usernameLabel);
        panel.add(usernameField);
        panel.add(passwordLabel);
        panel.add(passwordField);
        panel.add(loginButton);
        panel.add(cancelButton);
        frame.add(panel);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }
}
