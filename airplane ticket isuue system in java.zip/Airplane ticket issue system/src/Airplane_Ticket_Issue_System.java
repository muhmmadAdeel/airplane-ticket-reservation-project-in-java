public class Airplane_Ticket_Issue_System {
    public static void main(String[] args) throws Exception {
        Database database = new Database("e");
        
    }
}
