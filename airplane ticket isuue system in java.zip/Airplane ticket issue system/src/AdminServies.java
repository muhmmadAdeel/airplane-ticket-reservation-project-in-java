

import java.util.Scanner;

public class AdminServies extends Admin {
    Scanner sc = new Scanner(System.in);
    

    public AdminServies(int Admin_ID,String username,String password){
        super(Admin_ID, username, password);
    }
    public void admin_menu(){
        while(true){
        Flight flight = new Flight();
        System.out.println("Welcome "+username+ " ...");
        System.out.println("1. Add new flight ");
        System.out.println("2. Modify flight ");
        System.out.println("3. Delete flight ");
        System.out.println("4. view flights detail");
        System.out.println("5. update profile ");
        System.out.println("6. logout ");
        int choice = sc.nextInt();
        switch(choice){
            case 1:
                addFlight();
                break;
            case 2:
                ModifyFlight();
                break;
            case 3:
                flight.deleteFlight();
                break;
            case 4:
                flight.getFlightDetails();
                break;
            case 5:
                update_profile();
                break;
            case 6:
                return;
            default:
                break;
        }
    }
    }
    public void addFlight(){
        int Flight_ID;
        String Flight_No,Departure_time,Arrive_time,Origen;

        System.out.println("Enter Flight_ID");
        Flight_ID = sc.nextInt();
        sc.nextLine();
        System.out.println("Enter flight Number ");
        Flight_No = sc.nextLine();
        System.out.println("Enter departure time (yyyy-MM-dd hh:mm a)");
        Departure_time = sc.nextLine();
        System.out.println("Enter arrive time (yyyy-MM-dd hh:mm a)");
        Arrive_time = sc.nextLine();
        System.out.println("Enter origen ");
        Origen = sc.nextLine();
        System.out.println("Enter destination ");
        String destination = sc.nextLine();
        System.out.println("Enter price ");
        double price = sc.nextDouble();
        Flight flight = new Flight();
        System.out.println("are you confirm to add new flight ?? (1/0)");
        int ch = sc.nextInt();
        if(ch == 1){
        flight.addflight(Flight_ID, Flight_No, Departure_time, Arrive_time, Origen,destination,price);
    }
    }
    public void ModifyFlight(){
        Flight flight = new Flight();
        System.out.println("Enter Flight ID ");
        int flight_ID = sc.nextInt();
        String Flight_No,Departure_time,Arrive_time,Origen;
        sc.nextLine();
        System.out.println("Enter flight Number ");
        Flight_No = sc.nextLine();
        System.out.println("Enter departure time (yyyy-MM-dd hh:mm a)");
        Departure_time = sc.nextLine();
        System.out.println("Enter arrive time (yyyy-MM-dd hh:mm a)");
        Arrive_time = sc.nextLine();
        System.out.println("Enter origen ");
        Origen = sc.nextLine();
        System.out.println("Enter destination :");
        String destination = sc.nextLine();
        System.out.println("Enter price ");
        double price = sc.nextDouble();
        System.out.println("are you confirm to modify new flight ?? (1/0)");
        int ch = sc.nextInt();
        if(ch == 1){
            flight.updateFlight(flight_ID, Flight_No, Departure_time, Arrive_time, Origen,destination,price);
        }
    }
    public void update_profile(){
        System.out.println("username is ");
        System.out.println("ID : "+get_Admin_ID());
        System.out.println("Username : "+get_Admin_username());
        System.out.println("Password : "+get_Admin_Password());
        System.out.println("you want to change password ?? (1/0)");
        int choice = sc.nextInt();
        if(choice == 1){
            sc.nextLine();
            System.out.println("Enter new password :");
            Admin_password = sc.nextLine();
            System.out.println("successfull ");
        }
    }
}
