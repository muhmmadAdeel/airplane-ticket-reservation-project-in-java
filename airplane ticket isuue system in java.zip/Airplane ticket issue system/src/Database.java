
import java.sql.*;
import java.util.Scanner;

public class Database {

    Scanner sc = new Scanner(System.in);
    private static final String DB_URL = "jdbc:mysql://localhost:3306/test";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "Adeel16616@!@";

    public void admin_login() {
        sc.nextLine();
        System.out.println("Enter Username or email::");
        String admin_username = sc.nextLine();
        System.out.println("Enter Password ::");
        String Admin_password = sc.nextLine();
        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD); Statement statement = connection.createStatement(); ResultSet resultSet = statement.executeQuery("SELECT admin_id,username,email, admin_password FROM admin_login")) {

            while (resultSet.next()) {
                int admin_id = resultSet.getInt("admin_id");
                String username_DB = resultSet.getString("username");
                String email_DB = resultSet.getString("email");
                String adminPassword_DB = resultSet.getString("admin_password");
                if (admin_username.equals(username_DB) || admin_username.equals(email_DB) && Admin_password.equals(adminPassword_DB)) {
                    AdminServies adminServies = new AdminServies(admin_id, admin_username, Admin_password);
                    adminServies.admin_menu();
                }
            }
        } catch (SQLException ex) {
            System.out.println("Error: " + ex.getMessage());
        }
    }

    public void login_user() {
        System.out.println("Enter username or email ");
        String username = sc.nextLine();
        System.out.println("Enter password ");
        String password = sc.nextLine();

        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD); Statement statement = connection.createStatement(); ResultSet resultSet = statement.executeQuery("SELECT user_ID,username, user_password, email FROM customer")) {

            while (resultSet.next()) {
                int user_ID = resultSet.getInt("user_ID");
                String Db_username = resultSet.getString("username");
                String Db_email = resultSet.getString("email");
                String Db_password = resultSet.getString("user_password");

                if ((username.equals(Db_username) || username.equals(Db_email)) && password.equals(Db_password)) {
                    customer customer1 = new customer();
                    customer1.login(user_ID, Db_username, password);
                    customer1.customer_menu();
                    break;
                }
            }
        } catch (SQLException ex) {
            System.out.println("Error: " + ex.getMessage());
        }
    }

    public void user_sign_up() {
        System.out.println("Enter Email ");
        String email = sc.nextLine();
        System.out.println("Enter Phone number ");
        String phoneNo = sc.nextLine();
        System.out.println("Enter username ");
        String username = sc.nextLine();
        System.out.println("Enter Password ");
        String password = sc.nextLine();
        String sql = "INSERT INTO customer (email, phone_no, username, user_password) VALUES (?, ?, ?, ?)";
        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD); PreparedStatement statement = connection.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS)) {
            statement.setString(1, email);
            statement.setString(2, phoneNo);
            statement.setString(3, username);
            statement.setString(4, password);
            int rowsInserted = statement.executeUpdate();
            if (rowsInserted > 0) {
                try (ResultSet generatedKeys = statement.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        int generatedId = generatedKeys.getInt(1);
                        customer user = new customer();
                        user.register(generatedId, email, phoneNo, username, password);
                        user.customer_menu();
                    }
                } catch (SQLException ex) {
                    System.out.println("Error retrieving generated keys: " + ex.getMessage());
                }
            } else {
                System.out.println("No rows inserted.");
            }
        } catch (SQLException ex) {
            System.out.println("Error: " + ex.getMessage());
        }
    }

    public Database() {
    }

    public Database(String e) {
        while (true) {
            System.out.println("Enter your choice:");
            System.out.println("1. Admin Login");
            System.out.println("2. User Login");
            System.out.println("3. User Sign Up");
            System.out.println("4. Exit");
            int choice = sc.nextInt();
            sc.nextLine();
            switch (choice) {
                case 1:
                    admin_login();
                    break;
                case 2:
                    login_user();
                    break;
                case 3:
                    user_sign_up();
                    break;
                case 4:
                    return;
                default:
                    System.out.println("Invalid choice, please try again.");
                    break;
            }
        }
    }

    public void add_flight_in_sql(int Flight_ID, String Flight_No, String Departure_time, String Arrive_time, String Origen, String destination, double price) {
        String sql = "INSERT INTO flight (flight_ID, Flight_No, Departure_time, Arrive_time, Origen,destination,price) VALUES (?, ?, ?, ?, ?,?,?)";

        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD); PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setInt(1, Flight_ID);
            statement.setString(2, Flight_No);
            statement.setString(3, Departure_time);
            statement.setString(4, Arrive_time);
            statement.setString(5, Origen);
            statement.setString(6, destination);
            statement.setDouble(7, price);

            int rowsInserted = statement.executeUpdate();
            if (rowsInserted > 0) {
                System.out.println("Flight record added successfully!");
            } else {
                System.out.println("Error: No rows inserted.");
            }

        } catch (SQLException ex) {
            System.out.println("Error found: " + ex.getMessage());
        }
    }

    public void Modify_flight_in_sql( int flight_id, String Flight_No, String Departure_time, String Arrive_time, String Origen, String destination, double price) {
        String sql = "UPDATE flight SET Flight_No = ?, Departure_time = ?, Arrive_time = ?, Origen = ? ,destination = ?, price = ? WHERE flight_ID = ?";

        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD); 
        PreparedStatement statement = connection.prepareStatement(sql)) {
            
            statement.setString(1, Flight_No);
            statement.setString(2, Departure_time);
            statement.setString(3, Arrive_time);
            statement.setString(4, Origen);
            statement.setString(5, destination);
            statement.setDouble(6, price);
            statement.setInt(7, flight_id);
            int rowsUpdated = statement.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("Successful update");
            } else {
                System.out.println("No flight record found with the provided ID.");
            }

        } catch (SQLException ex) {
            System.out.println("Error found: " + ex.getMessage());
        }
    }

    public void delete_flight_from_sql(int flight_ID, String flight_No) {
        String payment_sql = "DELETE FROM payment WHERE flight_id = ?";
        String booking_Sql = "DELETE FROM booking WHERE flight_id = ?";
        String sql = "DELETE FROM flight WHERE flight_id = ? AND flight_no = ?";
        try(Connection connection = DriverManager.getConnection(DB_URL,DB_USER,DB_PASSWORD);
        PreparedStatement statement = connection.prepareStatement(payment_sql)){
            statement.setInt(1,flight_ID);
            statement.executeUpdate();

        }catch (SQLException ex){
            System.out.println("error ");
        }

        try(Connection connection = DriverManager.getConnection(DB_URL,DB_USER,DB_PASSWORD);
        PreparedStatement statement = connection.prepareStatement(booking_Sql)){
            statement.setInt(1,flight_ID);
            statement.executeUpdate();

        }catch (SQLException ex){
            System.out.println("error ");
        }

        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
         PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setInt(1, flight_ID);
            statement.setString(2, flight_No);

            int rowsDeleted = statement.executeUpdate();
            if (rowsDeleted > 0) {
                System.out.println("Flight record deleted successfully!");
            } else {
                System.out.println("No flight record found with the provided ID and flight number.");
            }
        } catch (SQLException ex) {
            System.out.println("Error: " + ex.getMessage());
        }
    }

    public void show_flight_details(int flight_ID) {
        String sql = "SELECT * FROM flight WHERE flight_ID = ?";

        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD); PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, flight_ID);
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    int id = resultSet.getInt("flight_ID");
                    String flightNo = resultSet.getString("Flight_No");
                    String departureTime = resultSet.getString("Departure_time");
                    String arriveTime = resultSet.getString("Arrive_time");
                    String origin = resultSet.getString("Origen");
                    String destination = resultSet.getString("destination");

                    System.out.println("Flight ID: " + id);
                    System.out.println("Flight No: " + flightNo);
                    System.out.println("Departure Time: " + departureTime);
                    System.out.println("Arrive Time: " + arriveTime);
                    System.out.println("Origin: " + origin);
                    System.out.println("Destination " + destination);
                } else {
                    System.out.println("No flight found with the provided ID.");
                }
            }

        } catch (SQLException ex) {
            System.out.println("Error: " + ex.getMessage());
        }
    }

    public void admin_password_change(String password, int admin_id) {
        String sql = "UPDATE admin_login set admin_password = ? where admin_id = ?";
        try (Connection connection = DriverManager.getConnection(DB_URL, DB_URL, DB_PASSWORD); PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setString(1, password);
            statement.setInt(2, admin_id);
            int rowsInserted = statement.executeUpdate();
            if (rowsInserted > 0) {
                System.out.println("success ");
            } else {
                System.out.println("error ");
            }

        } catch (SQLException ex) {
            System.out.println("error " + ex);
        }
    }

    public void show_flight_details_for_customer() {
        String sql = "SELECT * FROM flight ";

        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD); PreparedStatement statement = connection.prepareStatement(sql)) {
            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    int id = resultSet.getInt("flight_ID");
                    String flightNo = resultSet.getString("Flight_No");
                    String departureTime = resultSet.getString("Departure_time");
                    String arriveTime = resultSet.getString("Arrive_time");
                    String origin = resultSet.getString("Origen");
                    String destination = resultSet.getString("destination");
                    double price = resultSet.getDouble("price");

                    System.out.println("\n");
                    System.out.println("Flight ID: " + id);
                    System.out.println("Flight No: " + flightNo);
                    System.out.println("Departure Time: " + departureTime);
                    System.out.println("Arrive Time: " + arriveTime);
                    System.out.println("Origin: " + origin);
                    System.out.println("Destination: " + destination);
                    System.out.println("Flight price : " + price);
                    System.out.println("\n\n");
                }
            }

        } catch (SQLException ex) {
            System.out.println("Error: " + ex.getMessage());
        }
    }

    public void create_Booking(int user_ID, int flight_ID, String status) {
        String sql = "INSERT INTO booking (user_ID, flight_ID, booking_status) VALUES ( ?, ?, ?)";
        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD); PreparedStatement statement = connection.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS)) {

            statement.setInt(1, user_ID);
            statement.setInt(2, flight_ID);
            statement.setString(3, status);
            int rowsInserted = statement.executeUpdate();

            if (rowsInserted > 0) {
                try (ResultSet generatedKeys = statement.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        int booking_ID = generatedKeys.getInt(1);

                        String get_priceSql = "SELECT flight.price FROM flight WHERE flight_id = ?";
                        try (PreparedStatement priceStatement = connection.prepareStatement(get_priceSql)) {
                            priceStatement.setInt(1, flight_ID);
                            try (ResultSet priceResultSet = priceStatement.executeQuery()) {
                                if (priceResultSet.next()) {
                                    double price = priceResultSet.getDouble("price");
                                    String paymentSql = "INSERT INTO payment (user_id,flight_id, booking_id, price) VALUES (?,?, ?, ?)";
                                    try (PreparedStatement payStatement = connection.prepareStatement(paymentSql)) {
                                        payStatement.setInt(1, user_ID);
                                        payStatement.setInt(2, flight_ID);
                                        payStatement.setInt(3, booking_ID);
                                        payStatement.setDouble(4, price);
                                        payStatement.executeUpdate();
                                    }
                                }
                            }
                        }
                        String ticketDetailsSql = "SELECT booking.booking_ID, booking.flight_ID, flight.Departure_time, flight.Arrive_time, flight.Origen, flight.Destination "
                                + "FROM booking "
                                + "JOIN flight ON booking.flight_ID = flight.flight_ID "
                                + "WHERE booking.booking_ID = ?";
                        try (PreparedStatement ticketStatement = connection.prepareStatement(ticketDetailsSql)) {
                            ticketStatement.setInt(1, booking_ID);
                            try (ResultSet ticketResultSet = ticketStatement.executeQuery()) {
                                if (ticketResultSet.next()) {
                                    int ticketID = ticketResultSet.getInt("booking_ID");
                                    int bookedFlightID = ticketResultSet.getInt("flight_ID");
                                    String departureTime = ticketResultSet.getString("Departure_time");
                                    String arriveTime = ticketResultSet.getString("Arrive_time");
                                    String origin = ticketResultSet.getString("Origen");
                                    String destination = ticketResultSet.getString("Destination");
                                    System.out.println("Booking Receipt:");
                                    System.out.println("Ticket ID: " + ticketID);
                                    System.out.println("Flight ID: " + bookedFlightID);
                                    System.out.println("Departure Time: " + departureTime);
                                    System.out.println("Arrival Time: " + arriveTime);
                                    System.out.println("Origin: " + origin);
                                    System.out.println("Destination: " + destination);
                                } else {
                                    System.out.println("Error: Booking details not found.");
                                }
                            }
                        }
                    }
                }
            } else {
                System.out.println("Error: No rows inserted.");
            }
        } catch (SQLException ex) {
            System.out.println("Error: " + ex.getMessage());
        }
    }

    public void cancelTicket(int booking_ID) {
        String sql = "DELETE FROM booking WHERE booking_id = ?";

        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
         PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setInt(1, booking_ID);
            int rowsDeleted = statement.executeUpdate();

            if (rowsDeleted > 0) {
                System.out.println("Flight cancelled successfully.");
            } else {
                System.out.println("No booking found with the provided ID.");
            }

        } catch (SQLException ex) {
            System.out.println("Error: " + ex.getMessage());
        }
    }

    public void user_viewProfile(int user_ID) {
        String sql = "SELECT * FROM customer WHERE user_ID = ?";

        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD); PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setInt(1, user_ID);

            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    int id = resultSet.getInt("user_id");
                    String email = resultSet.getString("email");
                    String phoneNo = resultSet.getString("phone_no");
                    String username = resultSet.getString("username");
                    String password = resultSet.getString("user_password");

                    System.out.println("Customer ID: " + id);
                    System.out.println("Email: " + email);
                    System.out.println("Phone Number: " + phoneNo);
                    System.out.println("Username: " + username);
                    System.out.println("Password: " + password);
                    System.out.println("-------------------------------");
                } else {
                    System.out.println("No user found with the provided ID.");
                }
            }

        } catch (SQLException ex) {
            System.out.println("Error: " + ex.getMessage());
        }
    }

    public void user_modifyProfile(int id, String email, String phone_no, String username, String password) {
        
        String sql = "UPDATE customer SET email = ?, phone_no = ?, username = ?, user_password = ? WHERE user_ID = ?";

        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD); 
        PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setString(1, email);
            statement.setString(2, phone_no);
            statement.setString(3, username);
            statement.setString(4, password);
            statement.setInt(5, id);

            int rowsUpdated = statement.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("Profile updated successfully.");
            } else {
                System.out.println("Error: No user found with the provided ID.");
            }

        } catch (SQLException ex) {
            System.out.println("Error: " + ex.getMessage());
        }
    }

    public void refund(int booking_ID, int ticket_ID) {
        String selectFlightSql = "SELECT flight_id FROM payment WHERE booking_id = ?";

        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD); PreparedStatement selectFlightStatement = connection.prepareStatement(selectFlightSql)) {

            selectFlightStatement.setInt(1, booking_ID);
            try (ResultSet resultSet = selectFlightStatement.executeQuery()) {
                if (resultSet.next()) {
                    int flight_ID = resultSet.getInt("flight_id");

                    String getPriceSql = "SELECT price, departure_time FROM flight WHERE flight_id = ?";
                    try (PreparedStatement priceStatement = connection.prepareStatement(getPriceSql)) {
                        priceStatement.setInt(1, flight_ID);
                        try (ResultSet priceResultSet = priceStatement.executeQuery()) {
                            if (priceResultSet.next()) {
                                double price = priceResultSet.getDouble("price");
                                String departureTime = priceResultSet.getString("departure_time");

                                Payment payment = new Payment();
                                if (payment.verifyPayment(departureTime)) {
                                    System.out.println("We will process your refund within 24 hours. Amount: " + price);

                                    String paymentSql = "DELETE FROM payment WHERE booking_id = ?";
                                    try (PreparedStatement payStatement = connection.prepareStatement(paymentSql)) {
                                        payStatement.setInt(1, booking_ID);
                                        payStatement.executeUpdate();
                                    }

                                    Booking booking = new Booking();
                                    booking.cancelBooking(ticket_ID);
                                } else {
                                    System.out.println("You are not eligible for a refund.");
                                }
                            }
                        }
                    }
                } else {
                    System.out.println("No booking found with the provided ID.");
                }
            }

        } catch (SQLException ex) {
            System.out.println("Error: " + ex.getMessage());
        }
    }

}
