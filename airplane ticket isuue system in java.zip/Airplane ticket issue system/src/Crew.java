public class Crew  {
    

    public int Crew_ID;
    public String name;
    public String email;
    public String password;
    public int assignFlightID;

    public Crew(){}
    public Crew(int Crew_ID,String name,String email,String password ,int assignFlightID){
        this.Crew_ID = Crew_ID;
        this.name = name;
        this.email = email;
        this.password = password;
        this.assignFlightID = assignFlightID;
    }

    public void viewPassengerList(){}
    public void updateCheckStatus(){}

    public int get_crew_ID(){
        return Crew_ID;
    }
    public String get_crew_email(){
        return email;
    }

    public String get_crew_password(){
        return password;
    }

}
