
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class Payment {

    String expireDate;

    Scanner sc = new Scanner(System.in);

    public void processPayment(int user_ID, int flight_ID) {
        System.out.println(".... debit card ....");
        sc.nextLine();
        System.out.println("Enter card number ");
        String card_No = sc.nextLine();
        System.out.println("Enter expire date (dd/mm/yyyy)");
        expireDate = sc.nextLine();
        System.out.println("Enter CVV number ");
        int cvv_No = sc.nextInt();
        boolean verify = verifyPayment(expireDate);
        if (verify) {
            Booking booking = new Booking();
            booking.createBooking(user_ID, flight_ID, "Confirmed");
        } else {
            System.out.println("Payment cancel");
        }
    }

    public boolean verifyPayment(String expire_date) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        sdf.setLenient(false);
        try {
            Date expirDate = sdf.parse(expire_date);
            Date date = new Date();
            System.out.println("true");
            return date.before(expirDate);
        } catch (ParseException e) {
            return false;
        }
    }

    public void refundPayment(int ticket_ID) {
        System.out.println("... For refund ... ");
        System.out.println("Enter booking ID ");
        int booking_id = sc.nextInt();
        Database database = new Database();
        database.refund(booking_id,ticket_ID);
    }

}
