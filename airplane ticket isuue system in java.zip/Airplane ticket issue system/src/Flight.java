
import java.util.Scanner;


public class Flight {
    Database db = new Database();
    public void addflight(int Flight_ID,String Flight_No,String Departure_time,String Arrive_time, String Origen,String destination,double price){
        db.add_flight_in_sql(Flight_ID, Flight_No, Departure_time, Arrive_time, Origen,destination,price);
    }
    public void updateFlight(int Flight_ID,String Flight_No,String Departure_time,String Arrive_time, String Origen,String destination,double price){
        db.Modify_flight_in_sql( Flight_ID, Flight_No, Departure_time, Arrive_time, Origen,destination,price);
    }
    Scanner sc = new Scanner(System.in);
    public void getFlightDetails(){
        System.out.println("Enter flight id ");
        int id = sc.nextInt();
        db.show_flight_details(id);
    }

    public void deleteFlight(){
        System.out.println("Enter Flight ID ");
        int id = sc.nextInt();
        sc.nextLine();
        System.out.println("Enter flight Number ");
        String Number = sc.nextLine();
        System.out.println("Are you confirm ?? (1/0)");
        int ch = sc.nextInt();
        if(ch == 1){
        db.delete_flight_from_sql(id,Number);}
        else{
            System.out.println("cancelled ");
        }
    }
}
