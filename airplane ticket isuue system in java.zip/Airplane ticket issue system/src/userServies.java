public class userServies extends customer {
    public void registerUser(){};
    public void loginUser(){};
    public void getUserDetails(){};
}
