
public class Admin{
    int Admin_ID;
    String username;
    String Admin_password;
    public Admin(){}
    public Admin(int Admin_ID,String username,String password){
        this.Admin_ID = Admin_ID;
        this.username = username;
        this.Admin_password =password;
    }
    public int get_Admin_ID(){
        return Admin_ID;
    }
    public String get_Admin_username(){
        return username;
    }

    public String get_Admin_Password(){
        return Admin_password;
    }
}