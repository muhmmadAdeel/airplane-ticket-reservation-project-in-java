
import java.util.Scanner;

public class customer {

    public int user_ID;
    public String email;
    public String Phone_No;
    public String username;
    public String user_password;
    Database database = new Database();
    Scanner sc = new Scanner(System.in);

    public void register(int id, String email, String Phone_No, String username, String password) {
        this.email = email;
        this.Phone_No = Phone_No;
        this.username = username;
        this.user_password = password;
        user_ID = id;
    }

    public void login(int user_id, String username, String password) {
        this.user_ID = user_id;
        this.username = username;
        this.user_password = password;
    }

    public void customer_menu() {
        while (true) {
            System.out.println("\n\nWelcome " + username);
            System.out.println("1. Book ticket ");
            System.out.println("2. cancel ticket ");
            System.out.println("3. view tickets ");
            System.out.println("4. view profile ");
            System.out.println("5. Modify profile");
            System.out.println("6. logout ");
            int ch = sc.nextInt();
            switch (ch) {
                case 1:
                    BookTicket(user_ID);
                    break;
                case 2:
                    cancelTicket();
                    break;
                case 3:
                    viewFlight();
                    break;
                case 4:
                    viewProfile();
                    break;
                case 5:
                    modifyProfile();
                    break;
                case 6:
                    return;
                default:
                    break;
            }
        }

    }

    public void viewFlight() {
        database.show_flight_details_for_customer();

    }

    public void BookTicket(int user_ID) {
        database.show_flight_details_for_customer();
        System.out.println("Enter flight ID: ");
        int flight_ID = sc.nextInt();
        sc.nextLine();
        System.out.println("Are you confirm? (1 for Yes / 0 for No)");
        int ch = sc.nextInt();
        if (ch == 1) {
            Payment payment = new Payment();
            payment.processPayment(user_ID, flight_ID);
        } else {
            System.out.println("Booking cancelled.");
        }
    }

    public void cancelTicket() {
        System.out.println("Enter ticket ID ");
        int ticket_ID = sc.nextInt();
        System.out.println("Are you confirm ?? (1/0)");
        int ch = sc.nextInt();

        if (ch == 1) {
            Payment payment = new Payment();
            payment.refundPayment(ticket_ID);
        }
    }

    public void viewProfile() {
        database.user_viewProfile(user_ID);

    }

    public void modifyProfile() {
        System.out.println("Enter ID ");
        int id = sc.nextInt();
        sc.nextLine();
        System.out.println("Enter Email ");
        String new_email = sc.nextLine();
        System.out.println("Enter Phone number ");
        String new_phoneNo = sc.nextLine();
        System.out.println("Enter username ");
        String new_username = sc.nextLine();
        System.out.println("Enter Password ");
        String new_password = sc.nextLine();
        System.out.println("are you confirm :(1/0)");
        int ch = sc.nextInt();
        if (ch == 1) {
            database.user_modifyProfile(id, new_email, new_phoneNo, new_username, new_password);
        } else {
            System.out.println("cancelled ");
        }
    }
}
