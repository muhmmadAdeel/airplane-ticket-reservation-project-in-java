
public class Booking {
    Database database = new Database();

    public void createBooking(int user_ID, int Flight_ID, String status) {
        database.create_Booking(user_ID, Flight_ID, status);

    }

    public void cancelBooking(int booking_ID) {
        database.cancelTicket(booking_ID);
    }
}
