CREATE DATABASE online_issue_ticket;

CREATE TABLE AdminLogin(
admin_id int PRIMARY KEY AUTO_INCREMENT,
username VARCHAR (30) UNIQUE,
email VARCHAR (100) UNIQUE,
admin_password VARCHAR (50),
Full_Name VARCHAR (50),
Phone_No VARCHAR (16) UNIQUE
);

CREATE TABLE t_customer(
user_id int PRIMARY KEY AUTO_INCREMENT,
email varchar (70) UNIQUE,
Phone_No VARCHAR (16) UNIQUE,
username VARCHAR (50) UNIQUE,
user_password VARCHAR (50)
);

CREATE TABLE t_flight(
flight_id int PRIMARY KEY AUTO_INCREMENT,
flight_No int UNIQUE,
departure_time VARCHAR (100),
arrive_time VARCHAR (100),
origin VARCHAR (70),
destination VARCHAR (70),
price decimal (12,2)
);


CREATE TABLE t_booking(
booking_id int PRIMARY KEY AUTO_INCREMENT,
user_id int,
flight_id int,
booking_status VARCHAR (100),
FOREIGN KEY (user_id) REFERENCES t_customer(user_id),
FOREIGN KEY (flight_id ) REFERENCES t_flight(flight_id)
);

CREATE TABLE t_payment (
recipt_id int PRIMARY KEY AUTO_INCREMENT,
user_id int,
flight_id int,
booking_id int,
FOREIGN KEY (user_id) REFERENCES t_customer(user_id),
FOREIGN KEY (flight_id) REFERENCES t_flight(flight_id),
FOREIGN KEY (booking_id) REFERENCES t_booking(booking_id)
);
